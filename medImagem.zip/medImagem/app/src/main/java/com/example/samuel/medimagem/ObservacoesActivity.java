package com.example.samuel.medimagem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.FloatingActionMenu;

public class ObservacoesActivity extends AppCompatActivity {

    private FloatingActionMenu menu;
    private FloatingActionButton button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_observacoes);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        menu = findViewById(R.id.fab_menu);
        button = findViewById(R.id.fab_audio);



    }




}
