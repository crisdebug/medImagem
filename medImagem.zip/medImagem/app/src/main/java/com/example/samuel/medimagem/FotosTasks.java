package com.example.samuel.medimagem;

import android.os.Handler;
import android.os.Message;

import java.io.File;
import java.util.ArrayList;

public class FotosTasks {

    private ArrayList<File> fotos;

    private static final int CARREGAR_CONTADOR_FOTOS = 1;
    private static final int CARREGAR_FOTOS = 2;
    private static final int SALVAR_FOTO = 3;
    private static final int SUCESSO = 4;
    private static final int FALHA = -1;


    public void start(FotosServiceCallback callback){
        IntentServiceHandler handler = new IntentServiceHandler(callback);
    }

    public Message obtemMessage(int msgWhat){
        Message message = new Message();
        message.what = msgWhat;
        return message;
    }

    private class IntentServiceHandler extends Handler{
        private final FotosServiceCallback callback;

        public IntentServiceHandler(FotosServiceCallback callback){
            this.callback = callback;
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case CARREGAR_CONTADOR_FOTOS:
                    try{

                    }
                    break;
                case CARREGAR_FOTOS:

                    break;
                case SALVAR_FOTO:

                    break;
                case SUCESSO:

                    break;
                case FALHA:

                    break;
            }
        }
    }

}
