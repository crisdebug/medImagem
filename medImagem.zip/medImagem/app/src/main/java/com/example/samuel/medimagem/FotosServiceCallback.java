package com.example.samuel.medimagem;

import java.io.File;
import java.util.ArrayList;

public interface FotosServiceCallback {
    void onSucessoFotos(ArrayList<File> fotos);
    void onSucessoContador(int count);
    void onSucessoSalvar();
    void onFalha();
}
