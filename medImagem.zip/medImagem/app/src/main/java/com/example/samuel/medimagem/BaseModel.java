package com.example.samuel.medimagem;

public interface BaseModel {
    int getItemViewType();
}
